RHYTHM Plugin v1.0.0 for Linux

Installation Instructions:
1. Extract this archive: tar -xzf rhythm-plugin-linux.tar.gz
2. Navigate to the extracted directory: cd rhythm-plugin-linux
3. Run the install script: ./install.sh
4. Follow the on-screen instructions
5. Launch RHYTHM from your application menu

System Requirements:
- Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- 4GB RAM minimum
- 500MB free disk space
- ALSA or PulseAudio

Features:
- Real-time collaboration
- Multi-track recording
- Plugin support
- Cloud synchronization
- JACK audio support

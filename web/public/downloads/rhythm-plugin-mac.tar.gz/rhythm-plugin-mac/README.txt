RHYTHM Plugin v1.0.0 for macOS

Installation Instructions:
1. Extract this archive
2. Run the install.sh script: ./install.sh
3. Follow the on-screen instructions
4. Launch RHYTHM from your Applications folder

System Requirements:
- macOS 10.15 or later
- 4GB RAM minimum
- 500MB free disk space

Features:
- Real-time collaboration
- Multi-track recording
- Plugin support
- Cloud synchronization
